module.exports = {
  owner: ['6289506883380@s.whatsapp.net']
}